#include<iostream>
#include<stdlib.h>
#include<stdio.h>


//opencv
#include <opencv2\objdetect\objdetect.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core.hpp>
#include <opencv2\core\core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\opencv.hpp>
#include <opencv2\objdetect\face.hpp>

 //file handling
#include<fstream>
#include<sstream>

//header files that contain functions
#include <facerec.h>

using namespace cv;
using namespace std;
using namespace cv::face;

int main()
{
	int choice;
	cout << "1. Recognise face\n";
	cout << "2. Add face\n";
	cout << "Choose One: ";
	cin >> choice;
	switch (choice)
	{
	case 1:
		FaceRecognition();
		break;
	case 2:
		addFace();
		eigenFaceTrainer();
		break;
	default:
		return 0;
	}
	//system("pause");
	return 0;
}